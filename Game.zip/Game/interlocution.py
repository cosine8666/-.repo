test = [
    "第一題題目敘述:\n(a) 選項一敘述\n(b) 選項二敘述\n(c) 選項三敘述\n(d) 選項四敘述\n\n",
    "第二題題目敘述:\n(a) 選項一敘述\n(b) 選項二敘述\n(c) 選項三敘述\n(d) 選項四敘述\n\n",
    "第三題題目敘述:\n(a) 選項一敘述\n(b) 選項二敘述\n(c) 選項三敘述\n(d) 選項四敘述\n\n"
]

personality = {
    1 : "第一型人格\n第一型人格敘述",
    2 : "第二型人格\n第二型人格敘述",
    3 : "第三型人格\n第三型人格敘述"
            }

class Question:
    def __init__(self, description, answer):
        self.description = description
        self.answer = answer

answers_list = [
    Question(test[0], 'a'),
    Question(test[1], 'a'),
    Question(test[2], 'a')
              ]

def run_test(answers_list):
    score = 0
    for number in answers_list:
        answer_input = input(number.description)
        if answer_input == number.answer:
                score += 1
        
    print("目前分數", str(score), "分,共", len(answers_list), "題, 你可能的人格為:", personality[score])

run_test(answers_list)

