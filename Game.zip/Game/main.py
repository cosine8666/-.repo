
#def add(a:int,b:int):
#    return a+b

# print(add(1,2))

#def module(a:int,b:int):
#    return a%b

#whatever=module(10,3)

# print(whatever)

#a1={"寵物":"貓貓","興趣":"遊戲","身高":159.5}

#print(a1["興趣"])

# import this

#a = 1 
#a = "friend"
#print(a)

#abc= [a+b for a,b in zip("123","456")]
#print(abc)

#abc = bytes(int(a)+int(b) for a,b in zip("123","456"))
#print(abc)

#abc = bytes(a^b for a,b in zip(b"123",b"456"))
#print(abc)

#print(b'a'^b'b')

#str(1) = int("31",base=16)

#var1 = 1
#var2 = 2
#print(1,2)

#for i in range(4):
#    print(i)

# cat = ["c","a","t","s"] # list列表 可以使用索引運算子
# print(cat[0])

# cat = [i for i in "cats"]
# print(cat)
#cat = ["cats"]
#print(cat)

#cat = [i for i in range(2,5)]
#print(cat)

#def cat(a:str,b:str):
#    return a+b 
#kitty = cat("你","好")
#print(kitty)

#cat = int(str(1))
#dog = int(str(2))
#print(cat+dog)

# cat = {1,9,2,1} #set集合 無法掌控順序
# cat.add(2)
# print(cat)

# cat = (1,2,3,"天氣好") #tuple元組
# cat[0]=100  #'tuple' object does not support item assignment
# print(cat[0])

# cat = {"耳朵":"毛毛的","眼睛":"大大的"} # dictonary字典
# print(cat["耳朵"])

# print(bytes("天氣好","utf-8")) #\xe5 e=1110 5=0101 一個中文字占3個bytes
# print(bytes("weather","utf-16"))

# cat = bytes("天氣好","utf-8")
# for i in cat :
    # print(hex(i))

# dog1 = bytes("天氣好","utf-8") 
# dog2 = bytes("出來玩","utf-8")
# cat = bytes(c^d for c,d in zip(dog1,dog2))
# print(cat)

# def XOR(var,key):return bytes(a^b for a,b in zip(var,key))
# print(XOR(bytes("abc","utf8"),bytes("def","utf-8")))

# def XOR(var,key):return [a^b for a,b in zip(var,key)]
# print(XOR(bytes("abc","utf8"),bytes("def","utf-8")))

# def XOR(var,key):return {a^b for a,b in zip(var,key)}
# print(XOR(bytes("abc","utf8"),bytes("def","utf-8")))

#bytes() b'\x05\x07\x05'
#[]      [5, 7, 5]
#{}      {5, 7}

# a=bytes("abc","utf-8")
# b=bytes("def","utf-8") #a,b = 設定整串資料
# print(bytes(c^d for c,d in zip(a,b))) #c,d=依序提取單個資料

# a=bytes("abc","utf-8")
# b=bytes("def","utf-8")
# def XOR(a,b):
#     return bytes(c^d for c,d in zip(a,b)) 
# print(XOR(a,b))

# a=bytes("abc","utf-8")
# print(a)

# def XOR(var,key):
#     return bytes(a^b for a,b in zip(var,key))
# print(XOR(bytes("abc","utf8"),bytes("def","utf-8")))

# var=bytes("abc","utf8")
# key=bytes("def","utf-8")
# def XOR(var,key):
#     return bytes(a^b for a,b in zip(var,key))
# print(XOR(var,key))

# abc = [c+d for c,d in zip("123","456")]
# print(abc)

# a = [1,2,3]
# b = [4,5,6]
# print(zip(a,b))

# a = [1,2,3]
# b = [4,5,6]
# print(*zip(a,b))
# print(*zip(*zip(a,b)))
# print(*zip(*zip(*zip(a,b))))

# def test1(x, *args):
#     print(x, args) 
# test1('a', 'b', 'c', 'd')

# kwargs= dict(a=1, b=2, c=3, d=4)
# def test2(**kwargs):
#     ''' 将所有关键字参数汇聚为 dict ''' 
# for key, value in kwargs.items():
#     print("{0} = {1}".format(key, value))
# print(test2)

# print("{} {}".format("hello", "world"))    # 不设置指定位置，按默认顺序
# print("{0}={1}".format("hello", "world"))  # 设置指定位置
# print("{1} {0} {1}".format("hello", "world"))  # 设置指定位置

# num = float(input("输入一个数字: "))

# print(locals()) 

# numbers:str = input("請輸入數字:")
# position = 0
# x = 0 
# # print(len(numbers))
# numberStringList:list = numbers.split(',')
# answer = set()
# while position < len(numberStringList):
#     number = int(numberStringList[position])
#     if number % 2 == 0:
#         answer.add(number)
#         x +=1
#     # if position > len(numbers):
#     #     break
#     position += 1
#     continue
# if x == 0:
#         print('No even number find')
# else:
#     answer = list(answer)
#     answer.sort()
#     print(answer)

# abc = [a+b for a,b in zip("123","456")]
# print(abc)
# ['14', '25', '36']

# abc = bytes(int(a)+int(b) for a,b in zip("123","456"))
# print(abc)
# b'\x05\x07\t'

# abc = bytes(a^b for a,b in zip(b"123",b"456"))
# print(abc)
# b'\x05\x07\x05'

# class Person:
  
#   # 定義class attribute，所有實體會共用它
#   kind = 'Person'
  
  # # 初始化，當宣告實體的時候這個方法會被呼叫
  # # 用self.xxx來定義實體的 attribute，每個被宣告的實體會有自己的attribute 
  # def __init__(self, name, age):
  #   self.name = name
  #   self.age = age
  #   print(f'{self.age=}')

#   # 定義實體的方法
#   def say_hi(self):
#     print(
#       f'Hi, my name is {self.name}, I am {self.age} years old'
#          )

# # 使用定義好的Class宣導實體(instance)
# mike = Person('Mike', 5) # 帶進去的參數Mike與5分辨對應__init__裡的name與age
# john = Person('John', 10)
# print(mike)

# # 呼叫實體的方法
# mike.say_hi() # output: Hi, my name is Mike, I am 5 years old
# john.say_hi() # output: Hi, my name is John, I am 10 years old

# # 印出實體attribute
# print(mike.name) # output: Mike
# print(john.name) # output: John

# # class attribute是共用的，不管是class本身或是instance都能使用
# print(mike.kind) # Person
# print(Person.kind) # Person

# hex_string = '0xff'
# number = int(hex_string, 16)
# print(number)
# s = hex(number)
# print(s)
# print(type(s))


# print(type(0x0000016B601DD490))

# print(type(int('0x0000021435DDC490',16)))

# msg = u'今天天氣真好'
# encoded = msg.encode('utf8')
# print(encoded)

# encoded = '\xe4\xbb\x8a\xe5\xa4\xa9\xe5\xa4\xa9\xe6\xb0\xa3\xe7\x9c\x9f\xe5\xa5\xbd'
# msg = encoded.decode('utf8')
# print(msg)