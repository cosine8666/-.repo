import pygame
import os

BLACK = (0, 0, 0)
pygame.init()
# test_dict= {}
# # test_dict['1'] = []
# # test_dict['2'] = []
# for i in range(6):
#     test_dict['1'] = 1
#     test_dict['2'] = 2
# print(test_dict['1'][3])

# class test(pygame.sprite.Sprite):
#      def __init__(self, size):
#         self.surface = pygame.Surface((50,40))
#         self.size = size
#         self.rect = self.surface.get_rect()
#         self.center = self.rect.center 
# x = test('2')
# print(type(x.center))        


